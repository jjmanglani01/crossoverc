Submission Folder structure
--------------------------------------------------------------------------------------------------------------------------------
script -> To load test data
source -> All source zip files
video -> video.mp4
Documents -> .docx file


Database setup
---------------------------------------------------------------------------------------------------------------------------------

Install MongoDB Server.
https://www.mongodb.com/download-center#community

Add mongod.exe file folder to PATH variable.

Run MongoDB server by "mongod" command.

Run MongoDB client by "mongo" command

Enter command "use stock-trader" to use "stock-trader" database.

Enter command load(scriptfile) for Test Data.

Get MongoDB driver for c++.

https://github.com/mongodb/mongo-cxx-driver/wiki/Download-and-Compile-the-Legacy-Driver.

At the end of the build you have directory which contains Include and lib folder which are used in following steps.

Build all and get all dll files to driver folder.

StockTradeService setup
-----------------------------------------------------------------------------------------------------------------------------------
Set Path of Include Directory(Right Click On Project->Property->Compiler->General->Additional Include Directories)  built in first step (mongodb-client directory)/include

Right Click On Project->Property->Compiler->PreCompiler PreCompiledHeader is set to Not Using option.

Set Path of Link Directory(Right Click On Project->Property->Linker->General->Additional Library Directories) built in first step(mongodb-client directory)/lib

Add cpprestsdk(casablanca) from "Right Click On Project->Manage NuGet Packages...." If Nuget is not installed please get first Nuget Package Manager.

Add postbuild command to copy dll from boost and mongodb to projects build folder. 

All is set for compilation and run the service.

StockTradeApp setup
--------------------------------------------------------------------------------------------------------------------------------------
Get Wt for your windows.
http://redmine.webtoolkit.eu/projects/1/wiki/Installing_Wt_on_MS_Windows
On above link follow the Easy Method.

Right Click On Project->Property->Compiler->PreCompiler PreCompiledHeader is set to Not Using option.

Add postbuild command to copy dll from wt to projects build folder. 

Careful with for which version(x86 or x64) you are build application.
In my case I got error with x86 works fine with x64.

Remaining Task and logic to implement the task
--------------------------------------------------------------------------------------------------------------------------------------
On server side, 
Buy/Sell/Portfolio Functions are remaining to Implement.

Portfolio - $lookup function can be used.

Buy - Check if amount is available with user and if available then deduct amount from trader "balancecash" and update portfolio and transaction collections.

Sell- Updae "balancecash" and "portfolio" collections

On client side,
Transaction/Buy/Sell/Portfolio

Transaction - Get data from json array and display it.

Portfolio - Call rest api get response if data is available render data in widget for portfolio.

Buy - Get stockcode and quantity to buy and call rest api and according to response display message.

Sell - Get stockcode and quantity to sell and call rest api and according to response display message.

UI
-------------------------------------------------------------------------------------------------------------------------------------
I have not created Web App with proper UI.

Video
-------------------------------------------------------------------------------------------------------------------------------------
Watch video by slowing down speed.(For vlc shortcut is "[".)

About Unit Test
----------------------------------------------------------------------------------------------------------------------------------------
My system updated from 8 to 8.1 and visual studio stop working so I could not add unit test as I will solve the problem I will add it and commit 
it to github repository. 

Repository link: https://github.com/jjmanglani01/crossoverc.git